#

BTstack allows to implement and use GATT Clients in a modular way.

