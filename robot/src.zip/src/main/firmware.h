#pragma once

void firmware_update(char *url, int check_certificate);